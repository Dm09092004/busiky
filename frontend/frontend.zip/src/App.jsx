import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Register from './pages/Register';
import MyDay from './pages/MyDay';
import Projects from './pages/Projects';
import { Toaster } from 'react-hot-toast';
import Layout from './components/Layout';

// Защищённый маршрут: только для авторизованных
const PrivateRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <div>Загрузка...</div>;
  return user ? children : <Navigate to="/login" />;
};

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Toaster position="top-right" />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/my-day" element={
            <PrivateRoute>
              <Layout>
                <MyDay />
              </Layout>
            </PrivateRoute>
          } />
          <Route path="/projects" element={
            <PrivateRoute>
              <Layout>
                <Projects />
              </Layout>
            </PrivateRoute>
          } />
          <Route path="/" element={<Navigate to="/my-day" />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;