import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: {
      main: '#26A69A',   // мятный
      light: '#64B5F6',
      dark: '#00897B',
      contrastText: '#ffffff',
    },
    secondary: {
      main: '#FFB74D',   // тёплый акцент (оранжевый)
      contrastText: '#000000',
    },
    background: {
      default: '#F0F4F3', // очень светлый серо-зелёный
      paper: '#FFFFFF',
    },
    text: {
      primary: '#2C3E50',
      secondary: '#607D8B',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
    },
    button: {
      textTransform: 'none',
    },
  },
  shape: {
    borderRadius: 12,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 24,
          padding: '8px 24px',
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
        },
      },
    },
  },
});

export default theme;