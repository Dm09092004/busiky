// src/pages/MyDay.js
import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import Timer from '../components/Timer';
import Modal from '../components/Modal';
import {
  Container,
  Typography,
  Paper,
  Box,
  CircularProgress,
  List,
  ListItem,
  ListItemText,
  Chip,
} from '@mui/material';
import WorkIcon from '@mui/icons-material/Work';
import FreeBreakfastIcon from '@mui/icons-material/FreeBreakfast';
import LunchDiningIcon from '@mui/icons-material/LunchDining';

const MyDay = () => {
  const [schedule, setSchedule] = useState([]);
  const [loading, setLoading] = useState(true);
  const [breakModal, setBreakModal] = useState({ show: false, message: '' });
  const { user } = useAuth();

  const fetchSchedule = async () => {
    try {
      const res = await api.get('my-schedule/');
      setSchedule(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSchedule();
    const interval = setInterval(() => {
      const now = new Date();
      const currentSlot = schedule.find(slot => {
        const start = new Date(slot.start);
        const end = new Date(slot.end);
        return now >= start && now <= end;
      });
      if (currentSlot && currentSlot.type === 'break' && !breakModal.show) {
        let message = '';
        if (currentSlot.break_type === 'short') message = 'Короткий перерыв: отдохните 5 минут, сделайте разминку для глаз.';
        else if (currentSlot.break_type === 'long') message = 'Длинный перерыв: 15 минут. Пройдитесь, выпейте воды.';
        else if (currentSlot.break_type === 'lunch') message = 'Обеденный перерыв. Приятного аппетита!';
        setBreakModal({ show: true, message });
        setTimeout(() => setBreakModal({ show: false, message: '' }), 10000);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [schedule, breakModal.show]);

  if (loading) return <CircularProgress sx={{ display: 'block', mx: 'auto', mt: 4 }} />;

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        Мой день, {user?.first_name || user?.username}
      </Typography>
      {schedule.length === 0 ? (
        <Paper sx={{ p: 3, textAlign: 'center' }}>
          <Typography>На сегодня задач нет. Отдыхайте!</Typography>
        </Paper>
      ) : (
        <List>
          {schedule.map((slot, idx) => (
            <Paper key={idx} sx={{ mb: 2, p: 2 }}>
              <ListItem alignItems="flex-start">
                {slot.type === 'work' ? (
                  <>
                    <WorkIcon color="primary" sx={{ mr: 2 }} />
                    <ListItemText
                      primary={slot.task_title}
                      secondary={`${new Date(slot.start).toLocaleTimeString()} – ${new Date(slot.end).toLocaleTimeString()} (план: ${slot.planned_duration} мин)`}
                    />
                    <Timer taskId={slot.task_id} initialDuration={slot.duration} onComplete={fetchSchedule} />
                  </>
                ) : (
                  <>
                    {slot.break_type === 'lunch' ? <LunchDiningIcon color="secondary" sx={{ mr: 2 }} /> : <FreeBreakfastIcon color="success" sx={{ mr: 2 }} />}
                    <ListItemText
                      primary={
                        slot.break_type === 'short' ? 'Короткий перерыв' :
                        slot.break_type === 'long' ? 'Длинный перерыв' : 'Обед'
                      }
                      secondary={`${new Date(slot.start).toLocaleTimeString()} – ${new Date(slot.end).toLocaleTimeString()}`}
                    />
                  </>
                )}
              </ListItem>
            </Paper>
          ))}
        </List>
      )}
      <Modal show={breakModal.show} onClose={() => setBreakModal({ show: false, message: '' })} title="Перерыв" message={breakModal.message} />
    </Container>
  );
};

export default MyDay;