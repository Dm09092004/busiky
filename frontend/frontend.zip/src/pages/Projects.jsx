// src/pages/Projects.js
import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import CreateProjectModal from '../components/CreateProjectModal';
import { Link } from 'react-router-dom';
import {
  Container,
  Typography,
  Button,
  Grid,
  Card,
  CardContent,
  CardActions,
  LinearProgress,
  Box,
  Chip,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

const Projects = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const { user } = useAuth();

  const isManager = user?.role === 'manager' || user?.role === 'admin';

  const fetchProjects = async () => {
    try {
      const url = isManager ? 'dashboard/' : 'projects/';
      const res = await api.get(url);
      setProjects(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleProjectCreated = () => fetchProjects();

  if (loading) return <CircularProgress sx={{ display: 'block', mx: 'auto', mt: 4 }} />;

  return (
    <Container maxWidth="xl" sx={{ mt: 4 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Проекты</Typography>
        {isManager && (
          <Button variant="contained" startIcon={<AddIcon />} onClick={() => setModalOpen(true)}>
            Создать проект
          </Button>
        )}
      </Box>
      {projects.length === 0 ? (
        <Typography>Нет проектов</Typography>
      ) : (
        <Grid container spacing={3}>
          {projects.map((proj) => (
            <Grid item xs={12} sm={6} md={4} key={proj.project_id || proj.id}>
              <Card>
                <CardContent>
                  <Typography variant="h6" component="div">
                    {proj.project_name || proj.name}
                  </Typography>
                  <Chip label={proj.status || 'новый'} size="small" sx={{ mt: 1 }} />
                  {isManager && (
                    <>
                      <Box sx={{ mt: 2 }}>
                        <Typography variant="body2" color="text.secondary">
                          Прогресс: {proj.progress?.toFixed(0) || 0}%
                        </Typography>
                        <LinearProgress variant="determinate" value={proj.progress || 0} />
                      </Box>
                      <Typography variant="body2" sx={{ mt: 1 }}>
                        Задач: {proj.completed_tasks || 0} / {proj.total_tasks || 0}
                      </Typography>
                    </>
                  )}
                </CardContent>
                <CardActions>
                  <Button size="small" component={Link} to={`/projects/${proj.project_id || proj.id}`}>
                    Подробнее
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
      <CreateProjectModal isOpen={modalOpen} onClose={() => setModalOpen(false)} onProjectCreated={handleProjectCreated} />
    </Container>
  );
};

export default Projects;