// src/components/Timer.js
import React, { useState, useEffect, useRef } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { Box, Button, Typography } from '@mui/material';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import PauseIcon from '@mui/icons-material/Pause';
import StopIcon from '@mui/icons-material/Stop';

const Timer = ({ taskId, initialDuration, onComplete }) => {
  const [timeLeft, setTimeLeft] = useState(initialDuration * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [timeEntryId, setTimeEntryId] = useState(null);
  const intervalRef = useRef(null);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const startTimer = async () => {
    if (isRunning) return;
    const now = new Date().toISOString();
    try {
      const res = await api.post('time-entries/', {
        task: taskId,
        start_time: now,
        end_time: null,
        duration: 0,
        notes: '',
      });
      setTimeEntryId(res.data.id);
      setIsRunning(true);
    } catch (error) {
      toast.error('Не удалось начать учёт времени');
    }
  };

  const stopTimer = async () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsRunning(false);
    if (timeEntryId) {
      const end = new Date().toISOString();
      try {
        await api.patch(`time-entries/${timeEntryId}/`, { end_time: end });
        toast.success('Время сохранено');
        if (onComplete) onComplete();
      } catch (error) {
        toast.error('Ошибка сохранения времени');
      }
    }
    setTimeEntryId(null);
    setTimeLeft(initialDuration * 60);
  };

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(intervalRef.current);
            stopTimer();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(intervalRef.current);
  }, [isRunning]);

  return (
    <Box display="flex" alignItems="center" gap={1}>
      <Typography variant="body2" fontFamily="monospace">
        {formatTime(timeLeft)}
      </Typography>
      {!isRunning ? (
        <Button size="small" variant="outlined" startIcon={<PlayArrowIcon />} onClick={startTimer}>Старт</Button>
      ) : (
        <Button size="small" variant="outlined" startIcon={<PauseIcon />} onClick={() => setIsRunning(false)}>Пауза</Button>
      )}
      <Button size="small" variant="outlined" startIcon={<StopIcon />} onClick={stopTimer}>Стоп</Button>
    </Box>
  );
};

export default Timer;