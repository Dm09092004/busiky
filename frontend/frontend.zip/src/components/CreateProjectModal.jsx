import React from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField } from '@mui/material';

const CreateProjectModal = ({ isOpen, onClose, onProjectCreated }) => {
  const handleSubmit = () => {
    // временная заглушка
    onProjectCreated && onProjectCreated({});
    onClose();
  };
  return (
    <Dialog open={isOpen} onClose={onClose}>
      <DialogTitle>Создать проект</DialogTitle>
      <DialogContent>
        <TextField label="Название" fullWidth margin="normal" />
        <TextField label="Описание" fullWidth margin="normal" multiline rows={3} />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Отмена</Button>
        <Button onClick={handleSubmit}>Создать</Button>
      </DialogActions>
    </Dialog>
  );
};

export default CreateProjectModal;